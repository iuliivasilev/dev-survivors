import pandas as pd
from survivors.tree import CRAID
from survivors import constants as cnt
import numpy as np
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import StandardScaler

class tree_wrapper():
    def __init__(self, 
                 model_features=None,
                 standard_scaler=True,
                 tree = True,
                 smart_impute=True,
                 tree_features=None,
                 new_features=["depth", "numb", "size"],
                 depth=15, 
                 categ=[], 
                 balance=None, 
                 criterion="peto", 
                 min_samples_leaf=0.05,
                 cut=False,
                 woe=True,
                 signif=0.05,
                 max_features=1.0,
                 n_jobs=10,
                 **kwargs):
        """
        Initializes the tree_wrapper object with various parameters 
        which inds features if not specified, imputes missing values, scales the data, 
        and fits a tree model based on the input data.

        Args:
            model_features (list): List of features for the model. Default is None.
            standard_scaler (bool): Flag to indicate whether to use standard scaling. Default is True.
            tree (bool): Flag to indicate whether to use a tree. Default is True.
            smart_impute (bool): Flag to indicate imputation using tree. Default is True.
            tree_features (list): List of features for the tree. Default is None.
            new_features (list): List of new features to add. Default is ["depth", "numb", "size"].
            depth (int): Depth parameter for the tree. Default is 15.
            categ (list): List of categorical features. Default is an empty list.
            balance (None or str): Balance parameter for the tree. Default is None.
            criterion (str): Criterion parameter for the tree. Default is "peto".
            min_samples_leaf (float): Minimum samples in leaf nodes. Default is 0.05.
            cut (bool): Cut parameter for the tree. Default is False.
            woe (bool): Weight of evidence parameter for the tree. Default is True.
            signif (float): Significance level for the tree. Default is 0.05.
            max_features (float): Maximum number of features. Default is 1.0.
            n_jobs (int): Number of parallel jobs. Default is 10.
            **kwargs: Additional keyword arguments.

        Returns:
            None
        """
        self.init_craid = {
            "depth": depth,
            "balance": balance,
            "criterion": criterion,
            "categ": categ,
            "min_samples_leaf": min_samples_leaf,
            "cut": cut,
            "woe": woe,
            "signif": signif,
            "max_features": max_features,
            "n_jobs": n_jobs
            }
        
        self.smart_impute = smart_impute
        self.new_features = new_features

        if tree:
            if new_features == [] and self.smart_impute == False:
                self.use_tree = False
            else:
                self.use_tree = True
        else:
            self.use_tree = False    
            self.smart_impute = False
            self.new_features = []

        self.categ = categ
        self.tree_features = tree_features

        self.standard_scaler = standard_scaler
        self.model_features = model_features

    def fit_tree(self, X, y):
        """
        Finds features if not specified and fits a tree model based on the input data.
        
        Parameters:
            X : DataFrame
                The input features.
            y : Series
                The target variable.
        
        Returns:
            None
        """
        # Find features if not specified
        self.columns = list(X.columns)

        if self.categ is not None:
            self.numeric = [x for x in self.columns if x not in self.categ]
        else:   
            self.numeric = self.columns.copy()
            self.categ = []

        self.imputer = SimpleImputer(strategy='median', keep_empty_features=True, fill_value=0)
        self.scaler = StandardScaler()

        if self.use_tree:
            if self.tree_features is None:
                self.tree_features = self.columns.copy()
            
            self.numeric += list(set(self.new_features) & set(["l_size", "depth"]))
            self.categ += list(set(self.new_features) & set(["numb"]))

            self.init_craid['leaf_features'] = list(self.tree_features) + [cnt.TIME_NAME, cnt.CENS_NAME]
            self.tree = CRAID(**self.init_craid)
            self.tree.fit(X[self.tree_features], y)

    def fill(self, X, train=False):  
        """
        Fills missing values in the input features and returns the updated DataFrame. 

        Args:
            X: DataFrame, The input features.
            train: bool, Flag to indicate whether the function is called on training data. Default is False.

        Returns:
            DataFrame: The updated input features with missing values filled.
        """
        X = X.copy()[self.columns]

        if self.smart_impute:
            for col in X.columns:
                nulls = X[col].isnull()
                X.loc[nulls, col] = self.tree.predict(X, target=col)[nulls]

        if train:
            self.imputer.fit(X)
        X = pd.DataFrame(self.imputer.transform(X), columns=self.columns)
        return X
    
    def transform(self, X, train=False):
        """
        Transforms the input data by predicting values for the features in `new_features` based on the `tree` model. 
        Applies standard scaling to numeric features if `standard_scaler` is enabled. 
        Filters the data to include only `model_features` if specified. 
        Encodes categorical features using one-hot encoding. 
        If `train` is True, fits the scaler, records the encoded columns, and fills missing columns with zeros. 
        
        Args:
            X: DataFrame, The input features.
            train: bool, Flag to indicate whether the function is called on training data. Default is False.
        
        Returns:
            np.ndarray: the transformed data as a numpy array of type float32.
        """
        for feature in self.new_features:
            pred = self.tree.predict(X, mode="target", target=feature)
            X[feature] = pred

        if self.standard_scaler:
            if train:
                self.scaler.fit(X[self.numeric])
            X[self.numeric] = self.scaler.transform(X[self.numeric])
        
        if self.model_features is not None:
            X = X[self.model_features]

        X = pd.get_dummies(X, columns=self.categ, dtype=float)
        if train:
            self.encoded_columns = list(X.columns)
        else:
            X = pd.concat([X, pd.DataFrame(columns=list(set(self.encoded_columns) - set(X.columns)))]).fillna(0.0)
        X = X[self.encoded_columns]
        return X.values.astype(np.float32)
    
    def fill_transform(self, X, train=False):
        """
        Fills missing values in the input features and returns the updated DataFrame. 

        Args:
            X: DataFrame, The input features.
            train: bool, Flag to indicate whether the function is called on training data. Default is False.

        Returns:
            DataFrame: The updated input features with missing values filled.
        """
        X = self.fill(X, train)
        return self.transform(X, train)
    
    def fit_fill_transform(self, X, y):
        """
        Fits the model with the training data (X, y) and then applies the fill_transform method on the same data.
        
        Args:
            self: The object instance.
            X: The input features.
            y: The target variable.
            
        Returns:
            The transformed data after filling missing values with the trained model.
        """
        self.fit_tree(X, y)
        return self.fill_transform(X, train=True)
    
    def tolerance_find_best(*args, **kwargs):
        #for base_exepriments
        pass