EXP_PREFIX = "gan_experiments"

param_grid_gan = {
        "depth": [7],
        "balance": [None],
        "criterion": ["peto"],
        "min_samples_leaf": [0.05],
        "leaf_model": ["base_zero_after"],
        'cut': [False],
        "woe": [True],
        "signif": [0.05],
        "max_features": [1.0],
        "n_jobs": [10],
        "smart_impute": [True],
        "standard_scaler": [True],
        "dropout_p": [0.1, 0.2, 0.3],
        "bn_weight_init": [(0, 0.01)],
        "bn_bias_init": [0],
        "linear_init": ['Xavier'],
        "lr": [0.0003, 0.003, 0.01],
        #"alphas": [(1, 1, 0)],

        "alphas": [(1, 1, 1), (0, 1, 1), (1, 0, 1), (1, 1, 0)],
        "early_stopper": [True],
        "patience": [5],
        "save_path": ["tmp"],
        "gen_size": [50, 100, 150],
        "beta1": [0.9],
        "beta2": [0.999],
        "ngpu": [4],
        "batch_size": [0.01, 0.03, 0.05],
        #'new_features': [[]],
        "new_features": [["depth", "numb", "size"]]

}