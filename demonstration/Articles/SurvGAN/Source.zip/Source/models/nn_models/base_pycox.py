from tree.tree_wrapper import tree_wrapper
from pycox.models.cox_time import MLPVanillaCoxTime
import torchtuples as tt
import torch
import numpy as np
class base_pycox(tree_wrapper):
    """
        Base class for defining models from Pycox.
        To define a new model, you should inherit this class and redefine `pycox_model` attribute with a Pycox model.
    """
    def __init__(self, 
                 lr = 0.0001,
                 epochs = 20,
                 batch_size = 0.05,
                 num_nodes = [32, 32],
                 dropout = 0.1,
                 batch_norm = True,
                 output_bias = True,
                 verbose = True,             
                 early_stopper = True,
                 load_best = True,
                 patience = 10,
                 min_delta = 0,
                 num_durations = 20,
                 sub = 1,
                 tree=True,
                 smart_impute=True,
                 new_features=["depth", "numb", "size"],
                 standard_scaler=True,
                 gan_features=None,
                 craid_features=None,
                 depth=15,  
                 categ=[], 
                 balance=None, 
                 criterion="peto", 
                 min_samples_leaf=0.05,
                 cut=False,
                 woe=True,
                 signif=0.05,
                 max_features=1.0,
                 n_jobs=10,
                 **kwargs
        ):
        args = locals()
        args = {k: v for k, v in args.items() if k not in ["self", "__class__"]}
        super().__init__(**args)
        # NN parameters
        if early_stopper:
            self.callbacks = [tt.callbacks.EarlyStopping(patience=patience, dataset="train", min_delta=min_delta, load_best=load_best, rm_file=True)]
        else:
            self.callbacks = []
        self.num_nodes = num_nodes

        self.batch_norm = batch_norm
        self.dropout = dropout
        self.output_bias = output_bias

        self.lr = lr
        self.batch_size = batch_size
        self.epochs = epochs
        self.verbose = verbose
        self.net = None
        self.target = None
        self.val_target = None


        # PCHazard
        self.num_durations = num_durations
        self.sub = sub

    def fit(self, X, y, X_val=None, y_val=None):
        """
        Fits the model to the training data.

        Parameters:
            X (array-like): The input features of shape (n_samples, n_features).
            y (array-like): The target values.
            X_val (array-like, optional): The validation features of shape (n_samples_val, n_features).
            y_val (array-like, optional): The validation target values.

        Returns:
            log (dict): A dictionary containing the training and validation logs.
        """
        X_enriched = self.fit_fill_transform(X, y)
        print(f"[NN fitter] Enriched data shape={X_enriched.shape}")

        in_features = X_enriched.shape[1]
        #out_features = 1
    
        if self.net is None: 
            self.net = tt.practical.MLPVanilla(in_features, self.num_nodes, self.out_features, self.batch_norm,
                                    self.dropout, output_bias=self.output_bias)
        elif self.net=="coxtime":
            self.net = MLPVanillaCoxTime(in_features, self.num_nodes, self.batch_norm, self.dropout)
        #self.model = CoxPH(net, tt.optim.Adam)
        self.model = self.pycox_model(self.net, tt.optim.Adam)
        self.model.optimizer.set_lr(self.lr)

        batch_size = int(len(X) * self.batch_size)
        print(f"[DeepSurv fitter] Batch size={batch_size}")

        if self.target is None:
            self.target = (y['time'].copy(), y['cens'].copy())

        if self.val_target is None and X_val is not None:
            self.val_target = (y_val['time'].copy(), y_val['cens'].copy())

        if X_val is not None:
            X_val_enriched = self.fill_transform(X_val)
            valid_data = (X_val_enriched.copy(), self.val_target)
            val_batch_size = batch_size
        else:
            valid_data = None
            val_batch_size = None

        self.log = self.model.fit(X_enriched.copy(), 
                            self.target, 
                            batch_size, self.epochs, self.callbacks, self.verbose,
                            val_data=valid_data,
                            val_batch_size=val_batch_size)
        
        #self.model.compute_baseline_hazards()
        return self.log
    
    def show_scores(self):
        self.log.plot()

    def predict_at_times(self, X, bins, mode="surv", seed=None):
        """
        Predicts values at specified times

        Args:
            X: Input data for prediction.
            bins: Time points at which to make predictions.
            mode: The mode of prediction to make. Either "surv" or "hazard". Defaults to "surv". 
            seed: Random seed for reproducibility.

        Returns:
            Predicted values at the specified time points.
        """
        if seed is not None:
            torch.manual_seed(seed)

        x = self.fill_transform(X)
        if mode == "surv":
            surv_df = self.model.predict_surv_df(x)
            probabilities = surv_df.values.T
            observations = surv_df.index

            predictions = np.zeros((probabilities.shape[0], bins.shape[0]))

            for i in range(probabilities.shape[0]):
                predictions[i, :] = probabilities[i][np.clip(np.searchsorted(observations, bins) - 1, a_min=0, a_max=None)]
            return predictions
        
        elif mode == "hazard":
            hazard_df = self.model.predict_cumulative_hazards(x)
            probabilities = hazard_df.values.T
            observations = hazard_df.index

            predictions = np.zeros((probabilities.shape[0], bins.shape[0]))

            for i in range(probabilities.shape[0]):
                predictions[i, :] = probabilities[i][np.clip(np.searchsorted(observations, bins) - 1, a_min=0, a_max=None)]
            return predictions
        
        else:
            raise ValueError("Mode must be 'surv' or 'hazard'")
    
    def predict(self, X, target=None, seed=None):
        """
        Predicts the survival time using the survival model.

        Parameters:
            X : array-like
                The input features for prediction.
            target : None, optional
                The target variable to predict.
            seed : int, optional
                Random seed for reproducibility.

        Returns:
            array-like
                Predicted values based on the survival model.
        """

        if seed is not None:
            torch.manual_seed(seed)

        x = self.fill_transform(X)
        surv_df = self.model.predict_surv_df(x)
        probabilities = surv_df.values.T
        observations = surv_df.index

        idx = (probabilities >= 0.5).sum(axis=1)
        greater_0_5 = probabilities[np.arange(len(probabilities)), idx-1]
        less_0_5 = probabilities[np.arange(len(probabilities)), np.minimum(idx, probabilities.shape[1] - 1)]
        idx_closest_to_0_5 = np.where(greater_0_5 - 0.5 < 0.5 - less_0_5, idx-1, np.minimum(idx, probabilities.shape[1] - 1))
        
        return observations[idx_closest_to_0_5]