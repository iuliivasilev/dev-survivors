from nn_models.base_pycox import base_pycox
from pycox.models import CoxPH, CoxCC, CoxTime, PCHazard
from pycox.models import LogisticHazard, PMF, DeepHitSingle, MTLR

from functools import partial

class deepsurvCRAID(base_pycox):
    """
    CoxPH is a Cox proportional hazards model also referred to as DeepSurv

    [1] Jared L. Katzman, Uri Shaham, Alexander Cloninger, Jonathan Bates, Tingting Jiang, and Yuval Kluger. Deepsurv: personalized treatment recommender system using a Cox proportional hazards deep neural network. BMC Medical Research Methodology, 18(1), 2018.
    """
    def fit(self, X, y, X_val=None, y_val=None):
        self.out_features = 1
        self.pycox_model = CoxPH
        log = super().fit(X, y, X_val, y_val)
        self.model.compute_baseline_hazards()
        return log

class coxccCRAID(base_pycox):
    """
    Cox-CC is a proportional version of the Cox-Time model 

    [1] Jared L. Katzman, Uri Shaham, Alexander Cloninger, Jonathan Bates, Tingting Jiang, and Yuval Kluger. Deepsurv: personalized treatment recommender system using a Cox proportional hazards deep neural network. BMC Medical Research Methodology, 18(1), 2018.
    """
    def fit(self, X, y, X_val=None, y_val=None):
        self.out_features = 1
        self.pycox_model = CoxCC
        self.output_bias = False
        log = super().fit(X, y, X_val, y_val)
        self.model.compute_baseline_hazards()
        return log

class coxtimeCRAID(base_pycox): 
    """
    Cox-Time is a relative risk model that extends Cox regression beyond the proportional hazards

    [1] Håvard Kvamme, Ørnulf Borgan, and Ida Scheel. Time-to-event prediction with neural networks and Cox regression. Journal of Machine Learning Research, 20(129):1–30, 2019.
    """
    def fit(self, X, y, X_val=None, y_val=None):
        labtrans = CoxTime.label_transform()

        self.target = labtrans.fit_transform(y['time'].copy(), y['cens'].copy())
        if y_val is not None:
            self.val_target = labtrans.transform(y_val['time'].copy(), y_val['cens'].copy())

        self.pycox_model = partial(CoxTime, labtrans=labtrans)
        self.net = "coxtime"
        log = super().fit(X, y, X_val, y_val)
        self.model.compute_baseline_hazards()
        return log
    
class pchazardCRAID(base_pycox): 
    """
    The Piecewise Constant Hazard (PC-Hazard) model assumes that the continuous-time hazard function is constant in predefined intervals. It is similar to the Piecewise Exponential Models and PEANN, but with a softplus activation instead of the exponential function.
    """
    def fit(self, X, y, X_val=None, y_val=None):
        labtrans = PCHazard.label_transform(self.num_durations)
        self.output_bias = True

        self.target = labtrans.fit_transform(y['time'].copy(), y['cens'].copy())
        self.out_features = labtrans.out_features
        if y_val is not None:
            self.val_target = labtrans.transform(y_val['time'].copy(), y_val['cens'].copy())

        self.pycox_model = partial(PCHazard, duration_index=labtrans.cuts)
        log = super().fit(X, y, X_val, y_val)
        self.model.sub = self.sub
        return log
    
class lhazardCRAID(base_pycox): 
    """
    The Logistic-Hazard method parametrize the discrete hazards and optimize the survival likelihood. It is also called Partial Logistic Regression and Nnet-survival.
    """
    def fit(self, X, y, X_val=None, y_val=None):
        labtrans = LogisticHazard.label_transform(self.num_durations)

        self.target = labtrans.fit_transform(y['time'].copy(), y['cens'].copy())
        self.out_features = labtrans.out_features
        if y_val is not None:
            self.val_target = labtrans.transform(y_val['time'].copy(), y_val['cens'].copy())

        self.pycox_model = partial(LogisticHazard, duration_index=labtrans.cuts)
        log = super().fit(X, y, X_val, y_val)
        self.model = self.model.interpolate(self.sub)
        return log
    
class pmfCRAID(base_pycox): 
    """
    The PMF method parametrize the probability mass function (PMF) and optimize the survival likelihood. It is the foundation of methods such as DeepHit and MTLR.
    """
    def fit(self, X, y, X_val=None, y_val=None):
        labtrans = PMF.label_transform(self.num_durations)

        self.target = labtrans.fit_transform(y['time'].copy(), y['cens'].copy())
        self.out_features = labtrans.out_features
        if y_val is not None:
            self.val_target = labtrans.transform(y_val['time'].copy(), y_val['cens'].copy())

        self.pycox_model = partial(PMF, duration_index=labtrans.cuts)
        log = super().fit(X, y, X_val, y_val)
        self.model = self.model.interpolate(self.sub)
        return log
    
class deephit_sCRAID(base_pycox): 
    """
    DeepHit is a PMF method with a loss for improved ranking that can handle competing risks.
    """
    def fit(self, X, y, X_val=None, y_val=None):
        labtrans = DeepHitSingle.label_transform(self.num_durations)

        self.target = labtrans.fit_transform(y['time'].copy(), y['cens'].copy())
        self.out_features = labtrans.out_features
        if y_val is not None:
            self.val_target = labtrans.transform(y_val['time'].copy(), y_val['cens'].copy())

        self.pycox_model = partial(DeepHitSingle, duration_index=labtrans.cuts)
        log = super().fit(X, y, X_val, y_val)
        self.model = self.model.interpolate(self.sub)
        return log
    
class mtlrCRAID(base_pycox): 
    """
    The (Neural) Multi-Task Logistic Regression is a PMF methods.
    """
    def fit(self, X, y, X_val=None, y_val=None):
        labtrans = MTLR.label_transform(self.num_durations)

        self.target = labtrans.fit_transform(y['time'].copy(), y['cens'].copy())
        self.out_features = labtrans.out_features
        if y_val is not None:
            self.val_target = labtrans.transform(y_val['time'].copy(), y_val['cens'].copy())

        self.pycox_model = partial(MTLR, duration_index=labtrans.cuts)
        log = super().fit(X, y, X_val, y_val)
        self.model = self.model.interpolate(self.sub)
        return log