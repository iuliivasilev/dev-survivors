import torch
import pandas as pd
import numpy as np
from math import ceil

def impute_values(data, imputation_values):
    data_imputed = data.astype(float)
    for i in np.arange(len(data)):
        row = data[i]
        indices = pd.isna(row)
        if imputation_values is None:
            data_imputed[i][indices] = 0
        else:
            for idx in np.arange(len(indices)):
                if indices[idx]:
                    data_imputed[i][idx] = imputation_values[idx]
    return data_imputed


class CustomDataset(torch.utils.data.Dataset):
    def __init__(self, dataset, mode='train'):
        data_set = dataset['preprocess'].generate_data()

        train_data, valid_data, test_data, imputation_values = data_set['train'], data_set['valid'], data_set['test'], data_set['imputation_values']
        
        if mode == 'train':
            self.data = {'x': train_data['x'], 'e': train_data['e'], 't': train_data['t']}
        if mode == 'valid':
            self.data = {'x': valid_data['x'], 'e': valid_data['e'], 't': valid_data['t']}
        if mode == 'test':
            self.data = {'x': test_data['x'], 'e': test_data['e'], 't': test_data['t']}

        # impute values        
        self.data_x_imputed = impute_values(self.data['x'], imputation_values)

        print(f"Len of dataset: {len(self.data['x'])}")

    def __len__(self):
        return len(self.data['x'])

    def __getitem__(self, idx):
        return self.data_x_imputed[idx], self.data['e'][idx], self.data['t'][idx]


class Train_dataset(torch.utils.data.Dataset):
    def __init__(self, x, e, t, imp_values=None):
        self.data = {'x': x, 'e': e, 't': t}
        if imp_values is not None:
            self.data['x'] = impute_values(self.data['x'], imp_values)
    
    def __len__(self):
        return len(self.data['x'])
    
    def __getitem__(self, idx):
        return self.data['x'][idx], self.data['e'][idx], self.data['t'][idx]
    
class CustomDataLoader:
    def __init__(self, x, e, t, batch_size):
        self.x = np.array(x)
        self.e = e
        self.t = t
        self.batch_size = batch_size
        self.num_samples = len(x)

    def __iter__(self):
        not_cens_indices = np.where(self.e == 1)[0]
        cens_indices = np.where(self.e == 0)[0]

        not_cens_indices = np.random.permutation(not_cens_indices)
        cens_indices = np.random.permutation(cens_indices)

        full_batches = int(self.num_samples / self.batch_size)

        not_cens_bs = ceil(((len(not_cens_indices) / self.num_samples) * self.batch_size))
        cens_bs = max(self.batch_size - not_cens_bs, 1)
        for i in range(full_batches):
            batch_idx = np.concatenate([cens_indices[i * cens_bs : (i + 1) * cens_bs], not_cens_indices[i * not_cens_bs: (i + 1) * not_cens_bs]])
            batch_x = self.x[batch_idx]
            batch_t = self.t[batch_idx]
            batch_e = self.e[batch_idx]
            if len(batch_x) != 0:
                yield torch.tensor(batch_x), torch.tensor(batch_e), torch.tensor(batch_t) 
        if (self.num_samples % self.batch_size) != 0:
            batch_idx = np.concatenate([cens_indices[cens_bs * full_batches:], not_cens_indices[not_cens_bs * full_batches:]])
            batch_x = self.x[batch_idx]
            batch_t = self.t[batch_idx]
            batch_e = self.e[batch_idx]
            yield torch.tensor(batch_x), torch.tensor(batch_e), torch.tensor(batch_t) 
    def __len__(self):
        return ceil(self.num_samples / self.batch_size)