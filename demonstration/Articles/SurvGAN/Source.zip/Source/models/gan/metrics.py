import sksurv.metrics
import numpy as np
import torch

from lifelines.utils import concordance_index

CENS_NAME = 'cens'
TIME_NAME = 'time'

def get_y(cens, time):

    """
    Generate a structured numpy array containing cens and time values.
    
    Parameters:
    cens (array-like): event values.
    time (array-like): time values.
    
    Returns:
    numpy.ndarray: A structured numpy array containing event and time values.
    """

    cens, time = np.array(cens), np.array(time) 
    y = np.empty(dtype=[(CENS_NAME, bool), 
                        (TIME_NAME, np.float64)], 
                 shape=cens.shape[0])
    y[CENS_NAME] = cens
    y[TIME_NAME] = time
    return y

def get_bins(time, cens=None, mode='a', num_bins=100):

    """
    Generate an array of bins based on the given time data.
    Parameters:
    - time: A numpy array containing the time data.
    - cens: A numpy array containing the indices of censored time data. Default is None.
    - mode: A string indicating the mode of bin generation. Default is 'a'.
    - num_bins: An integer indicating the number of bins to generate. Default is 100.
    Returns:
    - bins: A numpy array containing the generated bins.
    """

    if not(cens is None):
        time = time[np.where(cens)]
    time = time.astype(np.int32)
    bins = np.array([])
    if mode == 'q':
        bins = np.quantile(time, np.arange(num_bins) / num_bins)
    elif mode == 'a':
        bins = np.arange(time.min(), time.max()+1)
    return bins


def rae(t: torch.Tensor, pred_t: torch.Tensor, event: torch.Tensor, axis=0) -> torch.Tensor:
        
        """
        Calculates Relative absolute error (RAE)

        Args:
        t: (Tensor) real time
        pred_t: (Tensor) predicted time
        event: (Tensor) censoring flag
        axis (int) aggregation method
        """

        cens = ~event.bool()
        abs_err = torch.abs(t - pred_t)
        pred_gr_emp = pred_t > t
        min_r = torch.minimum(abs_err / pred_t, torch.tensor(1.0, device=pred_t.device))
        rea = torch.where(torch.logical_and(cens, pred_gr_emp), torch.tensor(0.0, device=cens.device), min_r)
        if axis == 0:
            return torch.mean(rea).cpu().detach().numpy() # mean
        elif axis == -1:
            return rea.cpu().detach().numpy()

def ci(t, pred_t, event):

    """
    Calculates Concordance Index (CI)
    """

    try:
        train_ci = concordance_index(event_times=t, predicted_scores=pred_t, event_observed=event)
    except IndexError:
        train_ci = 0.0,
        print("C-Index IndexError")
    except ValueError:
        train_ci = 0.0
        print("C-Index ValueError")
    return train_ci

def ibs_remain(survival_test, estimate, times, axis=-1):

    """
    Calculates the Integrated Brier Score (IBS)

    Args:
    survival_test: ordered ndarray (the first field is the event flag, the second is the time). 
    It can be converted to the desired format by the get_y()
    estimate function: the return value from the predict_at_times() function
    times: the return value from the get_bins() function
    axis: (int) aggregation method

        - axis=-1: aggregation across all observations
        - axis=0: metric value for each observation
        - axis=1: metric value for each bins
    """

    test_event, test_time = sksurv.metrics.check_y_survival(survival_test, allow_all_censored=True)
    estimate = np.array(estimate)
    if estimate.ndim == 1 and times.shape[0] == 1:
        estimate = estimate.reshape(-1, 1)
    estimate[estimate == -np.inf] = 0
    estimate[estimate == np.inf] = 0

    estim_before = np.square(estimate) * test_event[np.newaxis, :].T
    estim_after = np.square(1 - estimate)
    brier_scores = np.array([np.where(test_time < t,
                                      estim_before[:, i],
                                      estim_after[:, i])
                             for i, t in enumerate(times)])
    N = np.sum(np.array([np.where(test_time < t,
                                      test_event,
                                      1)
                             for i, t in enumerate(times)]), axis=1)
    
    time_diff = times[-1] - times[0] if times[-1] > times[0] else 1
    if axis == -1:  # mean ibs for each time and observation
        brier_scores = np.where(N > 0, 1 / N, 0) * np.sum(brier_scores, axis=1)
        return np.trapz(brier_scores, times) / time_diff
    elif axis == 0:  # ibs for each observation
        return np.trapz(brier_scores, times, axis=0) / time_diff
    elif axis == 1:  # bs in time (for graphics)
        brier_scores = np.where(N > 0, 1 / N, 0) * np.sum(brier_scores, axis=1)
        return brier_scores
    return None

def auprc(survival_test, estimate, times, axis=-1):

    """
    Calculates the Area Under Precision-Recall Curve (AUPRC)

    Args:
    survival_test: ordered ndarray (the first field is the event flag, the second is the time). 
    It can be converted to the desired format by the get_y()
    estimate function: the return value from the predict_at_times() function
    bins: the return value from the get_bins() function
    axis: aggregation method

        - axis=-1: mean for each time and observation
        - axis=0: metric value for each observation
        - axis=1: metric value for each bins
        - axis=2: source
        - axis=3: metric value for each observation with array wrap
    """

    time = survival_test[TIME_NAME]
    event = survival_test[CENS_NAME]

    steps = np.linspace(1e-5, 1 - 1e-5, 100)
    before_time = np.dot(time[:, np.newaxis], steps[np.newaxis, :])
    after_time = np.dot(time[:, np.newaxis], 1 / steps[np.newaxis, :])
    
    before_ind = np.clip(np.searchsorted(times, before_time), 0, times.shape[0] - 1)
    after_ind = np.clip(np.searchsorted(times, after_time), 0, times.shape[0] - 1)

    est = np.take_along_axis(estimate, before_ind, axis=1)
    est[event] -= np.take_along_axis(estimate[event], after_ind[event], axis=1)

    if axis == -1:  # mean for each time and observation
        est = np.mean(est, axis=0)
        return np.trapz(est, steps)
    elif axis == 0:  # for each observation
        return np.trapz(est, steps)
    elif axis == 1:  # in time (for graphics)
        est = est.mean(axis=0)
        return est
    elif axis == 2:  # source
        return est
    elif axis == 3:  # for each observation with array wrap
        return np.array([np.trapz(est, steps)])
    return None