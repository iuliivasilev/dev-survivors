import torch
import torch.nn as nn
import numpy as np
import pandas as pd
from survivors.metrics import ibs_remain as IBS_remain

from gan.params import device, eps

# Custom weights initialization called on ``netG`` and ``netD``
def weights_init(m, bn_weight_init=(0, 1), bn_bias_init=0, linear_init='Xavier'):

    """
    Custom weights initialization called on netG and netD

    Args:
    m : module to call
    bn_weight_init: tuple (mean, std) for initializing BatchNorm weights with Normal distribution or int for for initializing BatchNorm weights with constant    
    bn_bias_init: int for initializing BatchNorm biases with constant
    linear_init:  'Kaiming', 'Xavier' or int for Kaiming initializing Xavier initializing or initializing with Normal distribution with std linear_init
    """

    classname = m.__class__.__name__
    if classname.find('Linear') != -1:
        if linear_init == 'Kaiming':
          torch.nn.init.kaiming_normal_(m.weight)
          torch.nn.init.zeros_(m.bias)
        elif linear_init == 'Xavier':
          torch.nn.init.xavier_normal_(m.weight)
          torch.nn.init.zeros_(m.bias)
        elif isinstance(linear_init, float):
          torch.nn.init.normal_(m.weight, std = linear_init)
          torch.nn.init.zeros_(m.bias)

    elif classname.find('BatchNorm') != -1:
        if  isinstance(bn_weight_init, tuple):
          nn.init.normal_(m.weight.data, mean=bn_weight_init[0], std=bn_weight_init[1])
        elif isinstance(bn_weight_init, int):
          nn.init.constant_(m.weight.data, bn_weight_init)
        nn.init.constant_(m.bias.data, bn_bias_init)

# Noise layer: add noise to the output of the previous layer during training
class Add_noise(torch.nn.Module):
    def __init__(self, noise_size, alpha=True):
        '''
        Combining noise with layer output
        '''
        self.noise_size = noise_size
        self.alpha = alpha

        super().__init__()

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        '''
        Combining noise with layer output
        '''
        
        if self.alpha:
            return  torch.column_stack([x, torch.rand((x.shape[0], self.noise_size), device=device)])
        else:
            return x

# Loss module, computes recon loss and returns it as a single value for backpropagation purposes
# Also calculates and returns the average observed and censored loss values, useful for logging and plotting
class recon_loss(torch.nn.Module):
    def __init__(self):
        super().__init__()

    def forward(self, t: torch.Tensor, pred_t: torch.Tensor, e: torch.Tensor) -> torch.Tensor:
        """
        Recon loss
        """
        censored = ~e.bool()
        event = e.bool()

        diff_time = torch.subtract(pred_t.flatten(), t.flatten())
        hinge = torch.nn.functional.relu(diff_time)

        observed_loss_i = torch.where(censored, torch.tensor(0.0, device=device), torch.abs(t.flatten() - pred_t.flatten()))
        censored_loss_i = torch.where(censored, hinge, torch.tensor(0.0, device=device))  
        
        cens_loss = censored_loss_i.sum() / censored.sum() if censored.sum() != 0 else torch.tensor(0.0, device=device)
        obs_loss = observed_loss_i.sum() / event.sum() if event.sum() != 0 else torch.tensor(0.0, device=device)
        return cens_loss + obs_loss


# Builder of the generator model
class Generator(nn.Module): 
    def __init__(self, ngpu, in_features=59, dropout_p=0.2, alphas=[True, True, True], gen_size=100):
        super(Generator, self).__init__()
        self.ngpu = ngpu
        self.alphas = alphas
        self.MLP = nn.Sequential(
            nn.Linear(in_features * (1 + alphas[0]), gen_size),
            nn.BatchNorm1d(gen_size),
            nn.ReLU(True),
            Add_noise(gen_size, alphas[1]),
            nn.Dropout(p=dropout_p),
            nn.Linear(gen_size * (1 + alphas[1]), gen_size),
            nn.BatchNorm1d(gen_size),
            nn.ReLU(True),
            Add_noise(gen_size, alphas[2]),
            #nn.Dropout(p=dropout_p),
            nn.Linear(gen_size * (1 + alphas[2]), 1),
        )

    def forward(self, x):
        if self.alphas[0]:
            x_plus_noise = torch.column_stack([x, torch.rand(x.shape, device=device)])
        else :
            x_plus_noise = x
        return torch.exp(self.MLP(x_plus_noise))
    
    def simple_KM(self, x, count_events=5):
        """
        Simple KM in case there are no censored events (for generated values).

        Args:
        x: ndarray (n_samples, m_features) - covariates
        net_G: Generator - generator with an input of dimension m
        count_events: int - count of generated events
        """
        obs =[np.zeros(len(x))] + [self.forward(x.to(device)).cpu().detach().numpy().flatten() for i in range(count_events)]
        obs = np.column_stack(obs)
        obs.sort(axis=1)
        p = [1 / count_events * i for i in range(count_events + 1)][::-1]
        return np.array(p), obs

    def predict_at_bins(self, X, bins, mode="surv", n_samples=10):
        p, obs = self.simple_KM(X, n_samples)
        res = np.zeros((obs.shape[0], bins.shape[0]))
        if mode == "surv":
            for i in range(len(obs)):
                res[i, :] = p[np.clip(np.searchsorted(obs[i], bins)-1, a_min=0, a_max=None)]
            return p, obs, res
                
        elif mode == 'hazard':
            p = - np.log(p+eps)
            for i in range(len(obs)):
                res[i, :] = p[np.clip(np.searchsorted(obs[i], bins)-1, a_min=0, a_max=None)]
            return p, obs, res

# Builder of the discriminator model
class Discriminator(nn.Module):
    def __init__(self, ngpu, in_features=59, dropout_p=0.2):
        super(Discriminator, self).__init__()
        self.ngpu = ngpu

        self.hidden_pair_one = nn.Sequential(
                nn.Linear(in_features, 50),
                nn.BatchNorm1d(50),
                nn.ReLU(True),
                nn.Dropout(p=dropout_p),
                nn.Linear(50, 50),
                nn.BatchNorm1d(50),
                nn.ReLU(True),
                nn.Dropout(p=dropout_p)
            )

        self.hidden_pair_two = nn.Sequential(
                nn.Linear(1, 50),
                nn.BatchNorm1d(50),
                nn.ReLU(True),
                nn.Dropout(p=dropout_p),
                nn.Linear(50, 50),
                nn.BatchNorm1d(50),
                nn.ReLU(True),
                nn.Dropout(p=dropout_p)
            )
        self.linear = nn.Linear(50 * 2, 1)

    def forward(self, x, t):
        pair_one = self.hidden_pair_one(x)
        pair_two = self.hidden_pair_two(t)
        return self.linear(torch.column_stack([pair_one, pair_two]))


import torch.optim as optim
from functools import partial
import tqdm
from gan.metrics import rae, ci, ibs_remain, auprc, get_bins, get_y
from gan.visualisation import show_losses, show_train_metrics, show_valid_metrics

class EarlyStopper:
    def __init__(self, patience=1, min_delta=0, start_from_epoch=0, path=None):
        self.patience = patience
        self.min_delta = min_delta
        self.counter = 0
        self.min_validation_loss = float('inf')
        self.path = path
        self.min_loss_epoch_number = -1
        self.counter_not_better = 0
        self.start_from_epoch = start_from_epoch

    def early_stop(self, validation_loss, model=None):
        print(f"[Early stopper]: Epoch={self.counter}, Current validation_loss={validation_loss}")
        self.counter += 1
        if self.counter <= self.start_from_epoch:
            return False
        if validation_loss < self.min_validation_loss:
            self.min_validation_loss = validation_loss
            self.min_loss_epoch_number = self.counter
            self.counter_not_better = 0
            if self.path is not None and model is not None:
                torch.save(model["netG"].state_dict(), (self.path + f"net_G.pth"))
                torch.save(model["netD"].state_dict(), (self.path + f"net_D.pth"))
        elif validation_loss > (self.min_validation_loss + self.min_delta) and self.counter > self.start_from_epoch:
            self.counter_not_better += 1
            if self.counter_not_better > self.patience:
                return True
        return False
    
    def restore_model(self):
        net_G = torch.load(self.path + f"net_G.pth")
        net_D = torch.load(self.path + f"net_D.pth")
        return net_G, net_D

class DATE_fitter():
    def __init__(self, in_features=None, dropout_p=0.2, bn_weight_init=(0, 0.01), bn_bias_init=0, linear_init='Xavier', alphas=(1, 1, 1), gen_size=100, lr=3e-4, beta1=0.9, beta2=0.999, early_stopper=None, ngpu=1, info=True):
        self.netG = Generator(ngpu, in_features, dropout_p, alphas=alphas, gen_size=gen_size).to(device)
        self.netG.apply(partial(weights_init, bn_weight_init=bn_weight_init, bn_bias_init=bn_bias_init, linear_init=linear_init))
        
        self.netD = Discriminator(ngpu, in_features, dropout_p).to(device)
        self.netG.apply(partial(weights_init, bn_weight_init=bn_weight_init, bn_bias_init=bn_bias_init, linear_init=linear_init))

        self.early_stopper = early_stopper

        if info:
            print("GAN info:")
            print(self.netG)
            print(self.netD)

        self.optimizerD = optim.Adam(self.netD.parameters(), lr=lr, betas=(beta1, beta2))
        self.optimizerG = optim.Adam(self.netG.parameters(), lr=lr, betas=(beta1, beta2))

    def fit(self, train_data, valid_data=None, batch_size=300, num_epochs=100, max_iters=4000, trace=False, gen_update=2, disc_update=1):

        rec_loss = recon_loss().to(device)

        self.train_log = dict(map(
            lambda k: (k, []),
            ['D_losses', 'G_losses', 'RAE', 'CI', 'IBS', 'AUPRC']
        ))

        self.val_logs = dict(map(
            lambda k: (k, []),
            ['RAE', 'CI', 'IBS', 'AUPRC']
        ))

        x_tr, t_tr, e_tr = train_data['x'], train_data['t'], train_data['e']

        x_tr_dev = torch.tensor(x_tr).to(device).float()
        t_tr_dev = torch.tensor(t_tr.copy()).to(device).float()
        e_tr_dev = torch.tensor(e_tr).to(device).float()

        train_dataset = Train_dataset(x_tr, e_tr, t_tr)
        train_dataloader = torch.utils.data.DataLoader(train_dataset, batch_size=batch_size, shuffle=True)

        if valid_data is not None:
            x_val, t_val, e_val = valid_data['x'], valid_data['t'], valid_data['e']

            x_val_dev = torch.tensor(x_val).to(device).float()
            t_val_dev = torch.tensor(t_val.copy()).to(device).float()
            e_val_dev = torch.tensor(e_val).to(device).float()

        iters = 0

        if trace:
            print("Start Training Loop...")
        
        for epoch in (pbar1 := tqdm.tqdm(range(num_epochs))):
            for i, data in enumerate(train_dataloader, 0):
                x, e, t = data
                not_cens_x = x[e == 1].to(device).float()
                not_cens_t = t[e == 1].to(device).float()
                not_cens_t = torch.unsqueeze(not_cens_t, dim = 1)

                if len(not_cens_t) <= 1:
                    continue

                x = x.to(device).float()
                t = torch.unsqueeze(t.to(device).float(), dim=1)
                e = e.to(device)
                for _ in range(gen_update):
                    self.netD.zero_grad()
                    self.netG.zero_grad()

                    fake = self.netG(x)

                    output_fake = self.netD.forward(x, fake).view(-1)
                    output_real = self.netD.forward(not_cens_x, not_cens_t).view(-1)
                    
                    errG = torch.mean(output_real) - torch.mean(output_fake)
                    errG = errG + rec_loss(fake, t, e)
                    errG.backward()
                    D_G_z2 = output_fake.mean().item()
                    self.optimizerG.step()

                for _ in range(disc_update):
                    self.netD.zero_grad()
                    self.netG.zero_grad()

                    fake = self.netG(x)

                    output_real = self.netD.forward(not_cens_x, not_cens_t).view(-1)
                    D_x = output_real.mean().item()

                    output_fake = self.netD.forward(x, fake.detach()).view(-1)
                    D_G_z1 = output_fake.mean().item()
                    
                    d_output_real = torch.sigmoid(output_real)
                    d_output_fake = torch.sigmoid(output_fake)
                    
                    errD = -torch.mean(torch.log(d_output_real+eps)) - torch.mean(torch.log(1 - d_output_fake+eps))
                    errD.backward()
                    self.optimizerD.step()


                # Output training stats
                self.train_log['G_losses'].append(errG.item())
                self.train_log['D_losses'].append(errD.item())

                if (trace == True):
                    with torch.no_grad():
                        pred_t = self.netG(x)
                        self.train_log['RAE'].append(rae(t, pred_t, e))
                        self.train_log['CI'].append(ci(t.cpu(), pred_t.cpu(), e.cpu()))
                        
                        times = get_bins(t.cpu().detach().numpy().flatten(), e.cpu().detach().numpy().flatten())
                        survival_test = get_y(e.cpu().detach().numpy().flatten(), t.cpu().detach().numpy().flatten())
                        _, _, estimate = self.netG.predict_at_bins(x, times, n_samples=5)
                        self.train_log['IBS'].append(ibs_remain(survival_test, estimate, times))
                        self.train_log['AUPRC'].append(auprc(survival_test, estimate, times))
                        
                        if (trace) and (i % 100 == 0):
                            print("Predicted: ", pred_t.mean())
                            print("Real: ", t.mean()) 
                        
                            print('[%d/%d][%d/%d]\tLoss_D: %.4f\tLoss_G: %.4f\tD(x): %.4f\tD(G(z)): %.4f / %.4f\tCI_train: %.4f\tRAE_train: %.4f'
                                % (epoch, num_epochs, i, len(train_dataloader),
                                errD.item(), errG.item(), D_x, D_G_z1, D_G_z2, self.train_log['CI'][-1], self.train_log['RAE'][-1]))
                if torch.any(torch.isnan(output_fake)):
                    return self.train_log, self.val_logs
                iters += 1

            if self.early_stopper is not None:
                times = get_bins(t_tr, e_tr)
                survival_test = get_y(e_tr, t_tr)
                _, _, estimate = self.netG.predict_at_bins(x_tr_dev, times, n_samples=5)
                loss = IBS_remain(None, survival_test, estimate, times)
                flag = self.early_stopper.early_stop(loss, {"netG": self.netG, "netD": self.netD})
                if flag:
                    if trace:
                        print(f'Early stopping... Epoch {epoch}')
                    break

            # Validation
            if valid_data is not None:
                with torch.no_grad():
                    pred_t = self.netG(x_val_dev)
                    self.val_logs['RAE'].append(rae(t_val_dev, pred_t, e_val_dev))                
                    pred_t = pred_t.cpu().detach().numpy().flatten()
                        
                    self.val_logs['CI'].append(ci(t_val, pred_t, e_val))

                    times = get_bins(t_val, e_val)
                    survival_test = get_y(e_val, t_val)
                    _, _, estimate = self.netG.predict_at_bins(x_val_dev, times, n_samples=5)
                    self.val_logs['IBS'].append(ibs_remain(survival_test, estimate, times))
                    self.val_logs['AUPRC'].append(auprc(survival_test, estimate, times))

                pbar1.set_description(f'Epoch: {epoch}, RAE_valid: {self.val_logs["RAE"][-1]:.4f}, CI_valid: {self.val_logs["CI"][-1]:.4f}, IBS_valid: {self.val_logs["IBS"][-1]:.4f}, AUPRC_valid: {self.val_logs["AUPRC"][-1]:.4f}')

            if max_iters != None and iters >= max_iters:
                break
        try:
            net_G, net_D = self.early_stopper.restore_model()
            self.netG.load_state_dict(net_G)
            self.netD.load_state_dict(net_D)
        except:
            pass
        return self.train_log, self.val_logs
    
    def show_scores(self):

        show_losses(self.train_log['G_losses'], self.train_log['D_losses'])
        show_train_metrics(self.train_log['RAE'], self.train_log['CI'], self.train_log['IBS'], self.train_log['AUPRC'])
        show_valid_metrics(self.val_logs['RAE'], self.val_logs['CI'], self.val_logs['IBS'], self.val_logs['AUPRC'])

    def scores(self, x, e, t, seed=None):
        if seed is not None:
            torch.manual_seed(seed)
        with torch.no_grad():
                pred_t = self.netG(torch.tensor(x).to(device).float())
                print("RAE: ", rae(torch.tensor(t).to(device).float(), pred_t, torch.tensor(e).to(device).float()))                
                pred_t = pred_t.cpu().detach().numpy().flatten()
                
                print("CI: ", ci(t, pred_t, e))
                times = get_bins(t, e)
                survival_test = get_y(e, t)
                _, _, estimate = self.netG.predict_at_bins(torch.tensor(x).to(device).float(), times, n_samples=5)
                print("IBS: ", ibs_remain(survival_test, estimate, times))
                print("AUPRC: ", auprc(survival_test, estimate, times))
        return pd.DataFrame(np.column_stack([t, pred_t]), columns=['gt_t', 'pred_t'])


from gan.datasets import Train_dataset  
from tree.tree_wrapper import tree_wrapper

class GanCRAID(tree_wrapper):
    def __init__(self, 
                 dropout_p = 0.2,
                 bn_weight_init = (0, 0.01),
                 bn_bias_init = 0,
                 linear_init = 'Xavier',
                 lr = 0.0003,
                 alphas = (1, 1, 1),
                 gen_size = 100,
                 beta1 = 0.5,
                 beta2 = 0.999,
                 ngpu = 1,
                 batch_size = 0.05,

                 early_stopper = True,
                 save_path = None,
                 patience = 5,
                 
                 min_delta = 0,
                 start_from_epoch = 0,
                 info = False, 
                 tree=True,
                 smart_impute=True,
                 new_features=["depth", "numb", "size"],
                 standard_scaler=True,
                 gan_features=None,
                 craid_features=None,
                 depth=15,  
                 categ=[], 
                 balance=None, 
                 criterion="peto", 
                 min_samples_leaf=0.05,
                 cut=False,
                 woe=True,
                 signif=0.05,
                 max_features=1.0,
                 n_jobs=10,
                 **kwargs
        ):
        args = locals()
        args = {k: v for k, v in args.items() if k not in ["self", "__class__"]}
        super().__init__(**args)

        ## GAN parameters
        if early_stopper:
            self.early_stopper = EarlyStopper(patience=patience, min_delta=min_delta, path=save_path, start_from_epoch=start_from_epoch)
        else:
            self.early_stopper = None

        self.init_gan = {
            "dropout_p": dropout_p,
            "bn_weight_init": bn_weight_init,
            "bn_bias_init": bn_bias_init,
            "linear_init": linear_init,
            "lr": lr,
            "early_stopper": self.early_stopper,
            "alphas": alphas,
            "gen_size": gen_size,
            "beta1": beta1,
            "beta2": beta2,
            "ngpu": ngpu,
            "info": info
        }

        self.batch_size = batch_size

    def fit(self, X, y, X_val=None, y_val=None, batch_size=300, num_epochs=35, max_iters=None, trace=False):

        X_enriched = self.fit_fill_transform(X, y)
        print(f"[GAN fitter] Enriched data shape={X_enriched.shape}")
        self.init_gan['in_features'] = X_enriched.shape[1]    
        self.GAN = DATE_fitter(**self.init_gan)

        train_data = {'x': X_enriched, 'e': y['cens'], 't': y['time']}

        batch_size = int(len(X) * self.batch_size)
        print(f"[GAN fitter] Batch size={batch_size}")
 
        if X_val is not None:
            X_val_enriched = self.fill_transform(X_val)
            valid_data = {'x': X_val_enriched, 'e': y_val['cens'].copy(), 't': y_val['time'].copy()}
        else:
            valid_data = None

        train_logs, val_logs = self.GAN.fit(train_data=train_data, valid_data=valid_data, num_epochs=num_epochs, batch_size=batch_size, max_iters=max_iters, trace=trace)

        return train_logs, val_logs
    
    def show_scores(self):
        self.GAN.show_scores()

    def scores(self, X, y, seed=None):
        if seed is not None:
            torch.manual_seed(seed)

        x = self.fill_transform(X)
        return self.GAN.scores(x, y['cens'].copy(), y['time'].copy(), seed=seed)
    
    def predict_at_times(self, X, bins, mode="surv", n_samples=20, seed=None):
        """
        Predicts values at specified times

        Args:
            X: Input data for prediction.
            bins: Time points at which to make predictions.
            mode: The mode of prediction. Defaults to "surv".
            n_samples: The number of samples to use for prediction. Defaults to 5.
            seed: Random seed for reproducibility.

        Returns:
            Predicted values at the specified time points.
        """
        if seed is not None:
            torch.manual_seed(seed)

        x = self.fill_transform(X)
        _, _, res =  self.GAN.netG.predict_at_bins(torch.tensor(x).to(device).float(), bins=bins, mode=mode, n_samples=n_samples)
        res[np.isnan(res)] = 0
        return res
    
    def predict(self, X, target=None, count=5, seed=None, reduce='mean'):
        if seed is not None:
            torch.manual_seed(seed)

        x = self.fill_transform(X)
        x = torch.Tensor(x)
        obs = [self.GAN.netG.forward(x.to(device)).cpu().detach().numpy().flatten() for i in range(count)]
        obs = np.column_stack(obs)
        obs[np.isnan(obs)] = 0
        if reduce == 'mean':
            obs = obs.mean(axis=1)
        elif reduce == 'sum':
            obs = obs.sum(axis=1)
        elif reduce == 'max':
            obs = obs.max(axis=1)
        elif reduce == 'min':
            obs = obs.min(axis=1)
        return obs
    
    def simple_KM(self, X, n_samples=1, seed=None):
        if seed is not None:
            torch.manual_seed(seed)

        x = self.fill_transform(X)
        return self.GAN.netG.simple_KM(torch.tensor(x).to(device).float(), count_events=n_samples)

    def tolerance_find_best(*args, **kwargs):
        #for base_exepriments
        pass