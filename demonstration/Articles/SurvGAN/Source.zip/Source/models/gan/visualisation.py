import matplotlib.pyplot as plt

def show_losses(G_losses, D_losses, tick_size=15, xlabel_size=15, title_size=20): 
    
    mosaic = '''
    ab
    '''
    fig, ax = plt.subplot_mosaic(mosaic)

    ax['a'].plot(G_losses, c='orange')
    ax['a'].set_title('Generator Loss during training', fontsize=title_size)
    ax['a'].tick_params(axis='both', labelsize=tick_size)
    ax['a'].set_xlabel("iterations", fontsize=xlabel_size)

    ax['b'].plot(D_losses, c='b')
    ax['b'].set_title('Discriminator Loss during training', fontsize=title_size)
    ax['b'].tick_params(axis='both', labelsize=tick_size)
    ax['b'].set_xlabel("iterations", fontsize=xlabel_size)

    fig.set_size_inches(18.5, 6.5)
    fig.suptitle('Generator and Discriminator losses')
    fig.tight_layout()

    fig.savefig('plots/gd_losses')
    plt.show()


def show_train_metrics(RAE_train, CI_train, IBS_train, AUPRC_train, tick_size=15, xlabel_size=15, title_size=20):
    mosaic = '''
    ab
    cd
    '''

    fig, ax = plt.subplot_mosaic(mosaic)

    ax['a'].plot(RAE_train, c='g')
    ax['a'].set_title('RAE during training', fontsize=title_size)
    ax['a'].tick_params(axis='both', labelsize=tick_size)
    ax['a'].set_xlabel("iterations", fontsize=xlabel_size)

    ax['b'].plot(CI_train, c='r')
    ax['b'].set_title('CI during training', fontsize=title_size)
    ax['b'].tick_params(axis='both', labelsize=tick_size)
    ax['b'].set_xlabel("iterations", fontsize=xlabel_size)

    ax['c'].plot(IBS_train, c='c')
    ax['c'].set_title('IBS during training', fontsize=title_size)
    ax['c'].tick_params(axis='both', labelsize=tick_size)
    ax['c'].set_xlabel("iterations", fontsize=xlabel_size)

    ax['d'].plot(AUPRC_train, c='y')
    ax['d'].set_title('AUPRC during training', fontsize=title_size)
    ax['d'].tick_params(axis='both', labelsize=tick_size)
    ax['d'].set_xlabel("iterations", fontsize=xlabel_size)

    fig.set_size_inches(18.5, 13)
    fig.suptitle('Metrics on train dataset')
    fig.tight_layout()

    fig.savefig('plots/train_metrics')
    plt.show()

def show_valid_metrics(RAE_valid, CI_valid, IBS_valid, AUPRC_valid, tick_size=15, xlabel_size=15, title_size=20):
    mosaic = '''
    ab
    cd
    '''

    fig, ax = plt.subplot_mosaic(mosaic)

    ax['a'].plot(RAE_valid, c='g')
    ax['a'].set_title('RAE during vatidation', fontsize=title_size)
    ax['a'].tick_params(axis='both', labelsize=tick_size)
    ax['a'].set_xlabel("epochs", fontsize=xlabel_size)

    ax['b'].plot(CI_valid, c='r')
    ax['b'].set_title('CI during vatidation', fontsize=title_size)
    ax['b'].tick_params(axis='both', labelsize=tick_size)
    ax['b'].set_xlabel("epochs", fontsize=xlabel_size)

    ax['c'].plot(IBS_valid, c='c')
    ax['c'].set_title('IBS during vatidation', fontsize=title_size)
    ax['c'].tick_params(axis='both', labelsize=tick_size)
    ax['c'].set_xlabel("epochs", fontsize=xlabel_size)

    ax['d'].plot(AUPRC_valid, c='y')
    ax['d'].set_title('AUPRC during vatidation', fontsize=title_size)
    ax['d'].tick_params(axis='both', labelsize=tick_size)
    ax['d'].set_xlabel("epochs", fontsize=xlabel_size)

    fig.set_size_inches(18.5, 13)
    fig.suptitle('Metrics on validation dataset')
    fig.tight_layout()

    fig.savefig('plots/valid_metrics')
    plt.show()


def show_survival(obs, p, bins=None, pred=None, count = 2, linewidth=3, xlabel_size=17, tick_size=17, title_size=20, legend_size=20):

    fig, axs = plt.subplots(1, count)

    for i in range(count):
        if bins is not None and pred is not None:
            axs[i].scatter(bins, pred[i], label='predicted at bins')
        axs[i].step(obs[i], p, where='post', c='r', linewidth=linewidth, label='simple KM')
        axs[i].set_title(f'observation {i}', fontsize=xlabel_size)
        axs[i].tick_params(axis='both', labelsize=tick_size)
        axs[i].set_xlabel("times", fontsize=xlabel_size)

        axs[i].legend(fontsize=xlabel_size)

    fig.set_size_inches(18.5, 6.5)
    fig.suptitle('Survival functions', fontsize=legend_size)
    fig.tight_layout()

    fig.savefig('plots/Survival functions')
    plt.show()