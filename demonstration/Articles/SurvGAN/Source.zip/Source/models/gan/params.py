device = 'cuda'
ngpu = 1
eps = 1e-16