# Prefix to use for all experiments with continuous data (i.e. survival data) using pycox
EXP_PREFIX = "continuous_pycox_exp"

# This dictionary defines the hyperparameter search space for all experiments with continuous data (i.e. survival data) using pycox
param_grid_pycox = {
        "depth": [7],
        "balance": [None],
        "criterion": ["peto"],
        "min_samples_leaf": [0.05],
        "leaf_model": ["base_zero_after"],
        'cut': [False],
        "woe": [True],
        "signif": [0.05],
        "max_features": [1.0],
        "n_jobs": [10],

        "tree": [False],
        "standard_scaler": [True],

        "num_nodes" : [[32, 32], [64, 64]],
        "batch_norm" : [True, False],
        "dropout" : [0.1, 0.3],
        "output_bias" : [True, False],
        "batch_size" : [0.01, 0.03, 0.05],
        "epochs" : [50],
        "verbose" : [True, False],
        "early_stopper" : [True],
        "load_best" : [True],
        "patience" : [35],
        "min_delta" : [0],

}