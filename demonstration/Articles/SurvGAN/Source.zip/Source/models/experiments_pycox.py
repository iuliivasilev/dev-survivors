import numpy as np
import pandas as pd
import os
import sys

from data.backblaze.load_new_backblaze import load_backblaze_2016_2018, load_backblaze_2018_2021, load_backblaze_2021_2023

from survivors.experiments import grid as exp

from nn_models.models_pycox import (
    deepsurvCRAID, 
    coxccCRAID, 
    coxtimeCRAID, 
    pchazardCRAID, 
    lhazardCRAID,
    deephit_sCRAID,
    mtlrCRAID, 
    pmfCRAID
)

import matplotlib.pyplot as plt
import seaborn as sns

sns.set()

SELF_ALGS = {
    "DeepSurv": deepsurvCRAID,
    "CoxCC": coxccCRAID,
    "CoxTime": coxtimeCRAID,
    "PCHazard": pchazardCRAID,
    "LogHazard": lhazardCRAID,
    "DeepHit": deephit_sCRAID,
    "MTLR": mtlrCRAID,
    "PMF": pmfCRAID
}

from common_pycox import param_grid_pycox, EXP_PREFIX

SCHEME_PARAMS = {
    "DeepSurv": param_grid_pycox,
    "CoxCC": param_grid_pycox,
    "CoxTime": param_grid_pycox,
    "PCHazard": param_grid_pycox,
    "LogHazard": param_grid_pycox,
    "DeepHit": param_grid_pycox,
    "MTLR": param_grid_pycox,
    "PMF": param_grid_pycox
}

PARAMS_ = {
    "backblaze_2016_2018": SCHEME_PARAMS,
    "backblaze_2018_2021": SCHEME_PARAMS,
    "backblaze_2021_2023": SCHEME_PARAMS
}

DATASETS_LOAD = {
    "backblaze_2016_2018": load_backblaze_2016_2018,
    "backblaze_2018_2021": load_backblaze_2018_2021,
    "backblaze_2021_2023": load_backblaze_2021_2023
}


def get_best_by_full_name(df_full, by_metric="IAUC", choose="max"):
    df = df_full.copy()
    df["METHOD"] = df.apply(lambda x: x["METHOD"].replace("CRAID", f"Tree({x['CRIT']})"), axis=1)
    if not (by_metric in df.columns):
        return None
    best_table = pd.DataFrame([], columns=df.columns)
    for method in df["METHOD"].unique():
        sub_table = df[df["METHOD"] == method]
        if sub_table.shape[0] == 0:
            continue
        if choose == "max":
            best_row = sub_table.loc[sub_table[by_metric].apply(np.mean).idxmax()]
        else:
            best_row = sub_table.loc[sub_table[by_metric].apply(np.mean).idxmin()]
        best_table = best_table.append(dict(best_row), ignore_index=True)
    return best_table


def plot_boxplot_results(df_full, dir_path=None, metrics=[],
                         dataset_name="", all_best=False,
                         by_metric="IAUC", choose="max"):
    if not(all_best):
        df_ = get_best_by_full_name(df_full, by_metric, choose)
    for m in metrics:
        if all_best:
            df_ = get_best_by_full_name(df_full, m, choose="min" if m == "IBS" else "max")
        plt.rcParams.update({'font.size': 15})
        fig, axs = plt.subplots(1, figsize=(8, 8))

        plt.title(f"{dataset_name} {m}")
        plt.boxplot(df_[m][::-1], labels=df_['METHOD'][::-1], showmeans=True, vert=False)
        if dir_path is None:
            plt.show()
        else:
            plt.savefig(os.path.join(dir_path, f"{dataset_name}_{m}_boxplot.png"))
            plt.close(fig)


def import_tables(dirs):
    dfs = []
    for d in dirs:
        dfs.append(pd.read_excel(d))
    df = pd.concat(dfs)
    df = df.drop_duplicates()
    for c in ["IBS", "IAUC", "CI", "CI_CENS"]:
        df[c] = df[c].apply(lambda x: list(map(float, x[1:-1].split())))
    return df


def run(dataset="GBSG", with_self=["TREE", "BSTR", "BOOST"],
        with_external=True, except_stop="all", mode="CV", bins_sch="", best_metric="IBS"):
    """
    Conduct experiments for defined dataset and methods (self and external)

    Parameters
    ----------
    dataset : str, optional
        Name of dataset (must be in DATASETS_LOAD). The default is 'GBSG'.
    with_self : list, optional
        Names of self models. The default is ["TREE", "BSTR", "BOOST"].
        "TREE" : CRAID,
        "BSTR" : BootstrapCRAID,
        "BOOST" : BoostingCRAID.
    with_external : boolean, optional
        Flag of addiction external models. The default is True.
        Models : CoxPHSurvivalAnalysis,
                 SurvivalTree,
                 RandomSurvivalForest,
                 GradientBoostingSurvivalAnalysis
    except_stop : str, optional
        Mode of ending because of exception. The default is "all".
        "all" - continue experiments
        else - stop experiments with current method

    dir_path : str, optional
        Path to the final directory

    Returns
    -------
    experim : Experiments
        Instance of class with constructed table.

    Examples
    --------
    from survivors.tests.experiment import run
    df_full, df_best = run()

    """
    lst_metrics = ["CI", "CI_CENS",
                   "IBS", "BAL_IBS", "IBS_WW", "BAL_IBS_WW", "IBS_REMAIN", "BAL_IBS_REMAIN",
                   "IAUC", "IAUC_WW", "IAUC_TI", "IAUC_WW_TI",
                   "AUPRC", "EVENT_AUPRC", "CENS_AUPRC", "BAL_AUPRC",
                   "KL", "LOGLIKELIHOOD"]
    if not (dataset in DATASETS_LOAD):
        print("DATASET %s IS NOT DEFINED" % (dataset))
    X, y, features, categ, sch_nan = DATASETS_LOAD[dataset]()
    
    experim = exp.Experiments(folds=5, except_stop=except_stop, dataset_name=dataset, mode=mode, bins_sch=bins_sch)
    experim.set_metrics(lst_metrics)
    experim.add_metric_best(best_metric)
    if with_external:
        pass
    if len(with_self) > 0:
        for alg in with_self:
            PARAMS_[dataset][alg]["categ"] = [categ]
            PARAMS_[dataset][alg]["ens_metric_name"] = [best_metric]
            experim.add_method(SELF_ALGS[alg], PARAMS_[dataset][alg])
    experim.run(X, y, verbose=1)
    return experim


#@pytest.fixture(scope="module")
def dir_path():
    return os.path.join(os.getcwd())


def test_dataset_exp(dir_path, dataset, best_metric, bins_sch="origin", mode="CV"):
    prefix = EXP_PREFIX  # identificator for results table (for example, name of tested model)
    res_exp = run(dataset, with_self=["DeepSurv", "CoxCC", "CoxTime", "PCHazard"],
                  with_external=False, mode=mode, # "with_external" for scoring scikit-survival model
                  bins_sch=bins_sch, best_metric=best_metric)

    df_full = res_exp.get_result()
    df_criterion = res_exp.get_best_by_mode(stratify="criterion")

    df_criterion.to_excel(os.path.join(dir_path, f"{prefix}_{dataset}_{mode}_best.xlsx"), index=False)
    df_full.to_excel(os.path.join(dir_path, f"{prefix}_{dataset}_{mode}_full.xlsx"), index=False)


"""
Script for launch experiments from console.

Usage:
    python experiments_pycox.py dataset_name

where dataset_name is name of dataset defined in DATASETS_LOAD:

    * backblaze_2016_2018
    * backblaze_2018_2021
    * backblaze_2021_2023

"""

if __name__ == "__main__":
    dataset = sys.argv[1]
    test_dataset_exp(dir_path(),        
                     dataset, 
                     "IBS_REMAIN", 
                     bins_sch="origin", mode="CV")

