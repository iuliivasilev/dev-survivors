import os
import numpy as np
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt

METHOD_MAP = {
    "CRAID": "TREE",
    "BootstrapCRAID": "BSTR", 
    "ParallelBootstrapCRAID": "PBSTR",
    "BoostingCRAID": "BOOST", 
    "IBSCleverBoostingCRAID": "BSTR",
    "CoxPHSurvivalAnalysis": "CoxPH",
    "SurvivalTree": "ST",
    "RandomSurvivalForest": "RSF",
    "ComponentwiseGradientBoostingSurvivalAnalysis": "CWGBSA",
    "GradientBoostingSurvivalAnalysis": "GBSA",
    "LeafSurviveAndHazard": "KM"}

def define_name(x):
    m = x["METHOD"]
    if m == "GanWithCRAID":
        params = eval(x["PARAMS"])
        if (params['smart_impute'] == False) and (params['new_features'] == []):
            m = "Gan"
        else:
            m = "GanWithCRAID"
    elif m.lower().startswith("gan"):
        return fr"${m}$"
    elif m.lower().endswith("craid")  and m != "CRAID":
        return fr"${m}$"
    else:
        s = m.split("_")
        m = METHOD_MAP.get(s[0], s[0])
        if len(s) > 1:
            m += "_{" + s[1] + "}"

        if x['l_m'] != "":
            m += "_{" + x['l_m'] + "}"
    return fr"${m}$"

DESCEND_METRICS = ["IBS", "IBS_WW", "IBS_REMAIN", "BAL_IBS"]

def find_best_index(df, ens_name="IBS_REMAIN"):
    if ens_name in DESCEND_METRICS:
        best_index = df[ens_name + "_mean"].sort_values(ascending=True).index[:5].tolist()
    else:
        best_index = df[ens_name + "_mean"].sort_values(ascending=False).index[:5].tolist()
    return best_index

def add_star_top3(column):
    top3_index = column.argsort()
    if column.name.split("_")[0] in DESCEND_METRICS:
        top3_index = top3_index[:3]
    else:
        top3_index = top3_index[-3:]
    column.iloc[top3_index] = "*" + column.iloc[top3_index].astype(str)
    return column

def pair_compare_load(glob_dir, ens_metric="IBS_REMAIN"):
    dfs = []
    paths = os.listdir(glob_dir)
    print("="*10, 'BACKBLAZE', "="*10)
    print(paths)

    for datasets_sc in paths:
        if datasets_sc.endswith("full.xlsx"):
            df_sc = pd.read_excel(os.path.join(glob_dir, datasets_sc))
            dfs.append(df_sc)

    tg_metrs = ["CI", "AUPRC", "BAL_AUPRC", "IBS", "IBS_REMAIN", "BAL_IBS_REMAIN"]
    new_metrs = [r"$CI$", r"$AUPRC$", r"$AUPRC_{BAL}$", r"$IBS$", r"$IBS_{RM}$", r"$IBS_{RM, BAL}$"]
    df = pd.concat(dfs, ignore_index=True)
    df["l_m"] = df["PARAMS"].apply(lambda x: eval(x).get("leaf_model", ""))
    
    df["METHOD"] = df.apply(define_name, axis=1)
    # Top-1

    from functools import partial

    # Top-5 by ens_metric_name
    df = df.loc[df.groupby('METHOD').apply(partial(find_best_index, ens_name=ens_metric)).sum()]
    
    sns.set(style="whitegrid", palette="Greys")

    colors = {}
    for method in df["METHOD"].unique():
        if method.lower().startswith("$gan"):
            colors[method] = "mediumslateblue"
        elif method.lower().endswith("craid$") and method != "$CRAID$":
            colors[method] = "lightblue"
        else:
            colors[method] = "lightgray"
    print(colors)
    l_df = []

    f, axes = plt.subplots(len(tg_metrs), 1, figsize=(10, 30), constrained_layout=True)
    for i, v in enumerate(tg_metrs):
        df[new_metrs[i]] = df[tg_metrs[i]]
        v = new_metrs[i]
        df[v] = df[v].apply(lambda x: np.array(list(map(float, x[1:-1].split()))))
        explode_res = df[[v, "METHOD"]].set_index(['METHOD']).apply(lambda x: x.explode()).reset_index()
        l_df.append(explode_res.groupby(by="METHOD").mean())

        sns.boxplot(x="METHOD", y=v, data=explode_res, ax=axes[i], showfliers=False, width=0.5, palette=colors)

        #axes[i].set_xticklabels([f"$textbf{x.get_text()}\$" for x in axes[i].get_xticklabels()], rotation=55)
        axes[i].tick_params(axis='x', rotation=55)
        axes[i].set_ylabel(v)
        axes[i].set_title("")

        sns.despine(ax=axes[i])
        axes[i].grid(True)

        axes[i].margins(x=0.05)

    res_table = pd.concat(l_df, axis=1).astype(float).round(3)
    res_table.columns = list(map(lambda x: x.replace("$", ''), res_table.columns))
    res_table = res_table.apply(add_star_top3)
    print(res_table)
    res_table.to_excel(os.path.join(glob_dir, f"backblaze_agg.xlsx"))

    plt.suptitle("")
    return df